"""
Batch Processing Script
Process multiple images and text files for emotion recognition
"""

import os
import cv2
import json
from deepface import DeepFace
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
from datetime import datetime
import argparse
from tqdm import tqdm
import pandas as pd

class BatchEmotionProcessor:
    """Process multiple files in batch mode"""
    
    def __init__(self):
        print("Initializing Batch Processor...")
        self.setup_models()
        
    def setup_models(self):
        """Load ML models"""
        # Text model
        print("Loading text sentiment model...")
        model_name = "j-hartmann/emotion-english-distilroberta-base"
        self.text_tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.text_model = AutoModelForSequenceClassification.from_pretrained(model_name)
        self.sentiment_pipeline = pipeline(
            "text-classification",
            model=self.text_model,
            tokenizer=self.text_tokenizer,
            top_k=None
        )
        print("✓ Text model loaded")
        
    def process_images(self, image_folder, output_file="image_results.json"):
        """Process all images in a folder"""
        print(f"\nProcessing images from: {image_folder}")
        
        if not os.path.exists(image_folder):
            print(f"Error: Folder {image_folder} does not exist")
            return None
        
        results = []
        image_files = [f for f in os.listdir(image_folder) 
                      if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp'))]
        
        if not image_files:
            print("No image files found")
            return None
        
        print(f"Found {len(image_files)} images")
        
        for img_file in tqdm(image_files, desc="Processing images"):
            img_path = os.path.join(image_folder, img_file)
            
            try:
                img = cv2.imread(img_path)
                
                # Analyze with DeepFace
                result = DeepFace.analyze(img, actions=['emotion'], 
                                        enforce_detection=False, silent=True)
                
                if isinstance(result, list):
                    result = result[0]
                
                results.append({
                    'filename': img_file,
                    'dominant_emotion': result['dominant_emotion'],
                    'emotions': result['emotion'],
                    'timestamp': datetime.now().isoformat()
                })
                
            except Exception as e:
                print(f"\nError processing {img_file}: {e}")
                results.append({
                    'filename': img_file,
                    'error': str(e),
                    'timestamp': datetime.now().isoformat()
                })
        
        # Save results
        with open(output_file, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\n✓ Results saved to {output_file}")
        self._print_summary(results, 'image')
        return results
    
    def process_text_file(self, text_file, output_file="text_results.json"):
        """Process text from a file (one text per line)"""
        print(f"\nProcessing text from: {text_file}")
        
        if not os.path.exists(text_file):
            print(f"Error: File {text_file} does not exist")
            return None
        
        results = []
        
        with open(text_file, 'r', encoding='utf-8') as f:
            texts = [line.strip() for line in f if line.strip()]
        
        if not texts:
            print("No text found in file")
            return None
        
        print(f"Found {len(texts)} text entries")
        
        for idx, text in enumerate(tqdm(texts, desc="Processing texts"), 1):
            try:
                # Get sentiment
                predictions = self.sentiment_pipeline(text)[0]
                predictions = sorted(predictions, key=lambda x: x['score'], reverse=True)
                
                results.append({
                    'text_id': idx,
                    'text': text,
                    'dominant_emotion': predictions[0]['label'],
                    'confidence': predictions[0]['score'],
                    'all_emotions': {p['label']: p['score'] for p in predictions},
                    'timestamp': datetime.now().isoformat()
                })
                
            except Exception as e:
                print(f"\nError processing text {idx}: {e}")
                results.append({
                    'text_id': idx,
                    'text': text,
                    'error': str(e),
                    'timestamp': datetime.now().isoformat()
                })
        
        # Save results
        with open(output_file, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\n✓ Results saved to {output_file}")
        self._print_summary(results, 'text')
        return results
    
    def process_csv(self, csv_file, text_column='text', output_file="csv_results.csv"):
        """Process text from a CSV file"""
        print(f"\nProcessing CSV: {csv_file}")
        
        try:
            df = pd.read_csv(csv_file)
            
            if text_column not in df.columns:
                print(f"Error: Column '{text_column}' not found in CSV")
                print(f"Available columns: {', '.join(df.columns)}")
                return None
            
            print(f"Found {len(df)} rows")
            
            # Add emotion columns
            emotions_list = []
            confidences = []
            
            for text in tqdm(df[text_column], desc="Processing texts"):
                try:
                    predictions = self.sentiment_pipeline(str(text))[0]
                    predictions = sorted(predictions, key=lambda x: x['score'], reverse=True)
                    
                    emotions_list.append(predictions[0]['label'])
                    confidences.append(predictions[0]['score'])
                    
                except Exception as e:
                    emotions_list.append('error')
                    confidences.append(0.0)
            
            df['predicted_emotion'] = emotions_list
            df['confidence'] = confidences
            
            # Save results
            df.to_csv(output_file, index=False)
            
            print(f"\n✓ Results saved to {output_file}")
            
            # Print statistics
            print("\nEmotion Distribution:")
            print(df['predicted_emotion'].value_counts())
            print(f"\nAverage Confidence: {df['confidence'].mean():.2%}")
            
            return df
            
        except Exception as e:
            print(f"Error processing CSV: {e}")
            return None
    
    def _print_summary(self, results, data_type):
        """Print processing summary"""
        successful = sum(1 for r in results if 'error' not in r)
        failed = len(results) - successful
        
        print(f"\n{'='*50}")
        print(f"PROCESSING SUMMARY ({data_type.upper()})")
        print(f"{'='*50}")
        print(f"Total processed: {len(results)}")
        print(f"Successful: {successful}")
        print(f"Failed: {failed}")
        
        if successful > 0:
            # Emotion distribution
            emotions = [r.get('dominant_emotion') for r in results if 'dominant_emotion' in r]
            from collections import Counter
            emotion_counts = Counter(emotions)
            
            print(f"\nEmotion Distribution:")
            for emotion, count in emotion_counts.most_common():
                percentage = (count / len(emotions)) * 100
                print(f"  {emotion}: {count} ({percentage:.1f}%)")
        
        print(f"{'='*50}\n")

def main():
    """Main function for command-line usage"""
    parser = argparse.ArgumentParser(description='Batch Emotion Recognition Processor')
    parser.add_argument('--mode', choices=['image', 'text', 'csv'], required=True,
                       help='Processing mode')
    parser.add_argument('--input', required=True, help='Input file or folder path')
    parser.add_argument('--output', help='Output file path (optional)')
    parser.add_argument('--text-column', default='text', 
                       help='Column name for text in CSV (default: text)')
    
    args = parser.parse_args()
    
    processor = BatchEmotionProcessor()
    
    if args.mode == 'image':
        output = args.output or 'image_results.json'
        processor.process_images(args.input, output)
        
    elif args.mode == 'text':
        output = args.output or 'text_results.json'
        processor.process_text_file(args.input, output)
        
    elif args.mode == 'csv':
        output = args.output or 'csv_results.csv'
        processor.process_csv(args.input, args.text_column, output)

if __name__ == "__main__":
    # Example usage without command line:
    print("Batch Emotion Processor")
    print("=" * 50)
    print("\nUsage examples:")
    print("\n1. Process images:")
    print("   python batch_processor.py --mode image --input ./images --output results.json")
    print("\n2. Process text file:")
    print("   python batch_processor.py --mode text --input texts.txt --output results.json")
    print("\n3. Process CSV:")
    print("   python batch_processor.py --mode csv --input data.csv --text-column review_text")
    print("\n" + "=" * 50)
    
    # Uncomment to run directly:
    # main()
    
    # Or use programmatically:
    # processor = BatchEmotionProcessor()
    # processor.process_images("path/to/images")
    # processor.process_text_file("path/to/texts.txt")
    # processor.process_csv("path/to/data.csv")