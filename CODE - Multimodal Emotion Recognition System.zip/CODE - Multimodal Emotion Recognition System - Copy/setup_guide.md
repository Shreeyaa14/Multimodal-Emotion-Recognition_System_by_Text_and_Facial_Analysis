# 🎭 Multimodal Emotion Recognition System
## Complete Setup and Usage Guide

---

## 📋 Table of Contents
1. [System Overview](#system-overview)
2. [Prerequisites](#prerequisites)
3. [Installation](#installation)
4. [Running the Application](#running-the-application)
5. [Features Guide](#features-guide)
6. [Troubleshooting](#troubleshooting)
7. [Advanced Usage](#advanced-usage)

---

## 🎯 System Overview

This advanced multimodal emotion recognition system combines:
- **Real-time facial emotion detection** using DeepFace (7 emotions: angry, disgust, fear, happy, sad, surprise, neutral)
- **Text sentiment analysis** using RoBERTa transformer model (7 emotions: anger, disgust, fear, joy, neutral, sadness, surprise)
- **Live visualization** with emotion timeline graphs
- **Session statistics** tracking emotional patterns
- **User-friendly GUI** built with Tkinter

---

## 🔧 Prerequisites

### System Requirements
- **OS**: Windows 10/11, macOS 10.14+, or Ubuntu 18.04+
- **Python**: 3.8, 3.9, 3.10, or 3.11 (recommended: 3.10)
- **RAM**: Minimum 8GB (16GB recommended)
- **Storage**: 5GB free space for models
- **Webcam**: Required for facial emotion detection

### Software Requirements
- Python installed with pip
- VS Code (or any Python IDE)
- Webcam drivers installed and working

---

## 📥 Installation

### Step 1: Clone or Download Project Files

Create a project folder and save these files:
- `emotion_recognition_system.py` (main application)
- `requirements.txt`

### Step 2: Create Virtual Environment (Recommended)

```bash
# Navigate to project directory
cd path/to/your/project

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate

# On macOS/Linux:
source venv/bin/activate
```

### Step 3: Install Dependencies

```bash
# Upgrade pip first
pip install --upgrade pip

# Install all requirements
pip install -r requirements.txt
```

**Note**: First-time installation may take 10-20 minutes as it downloads:
- PyTorch (~2GB)
- TensorFlow (~500MB)
- Transformer models (~500MB)
- DeepFace models (~100MB)

### Step 4: Verify Installation

```bash
python -c "import torch; import transformers; import cv2; import deepface; print('All packages installed successfully!')"
```

---

## 🚀 Running the Application

### Launch in VS Code

1. Open VS Code
2. Open the project folder (File → Open Folder)
3. Open `emotion_recognition_system.py`
4. Make sure your virtual environment is activated (check bottom-left of VS Code)
5. Press `F5` or run: `python emotion_recognition_system.py`

### First Launch

When you first run the application:
1. It will download required ML models (1-2 minutes)
2. You'll see console output: "Loading models... This may take a moment."
3. The GUI window will appear once models are loaded

---

## 🎨 Features Guide

### 1. Facial Emotion Detection

**How to Use:**
1. Click **"▶ Start Camera"** button
2. Position your face in front of the webcam
3. Real-time emotions will appear on screen:
   - Primary emotion with confidence percentage
   - Top 3 emotions with visual bars
   - Live video feed with annotations

**Detected Emotions:**
- 😠 Angry
- 🤢 Disgust  
- 😨 Fear
- 😊 Happy
- 😢 Sad
- 😲 Surprise
- 😐 Neutral

**Tips:**
- Ensure good lighting
- Face the camera directly
- Keep face centered in frame
- Avoid extreme angles

### 2. Text Sentiment Analysis

**How to Use:**
1. Type or paste text in the text input area
2. Click **"🔍 Analyze Text"** button
3. View results:
   - Primary emotion with confidence
   - Full emotion breakdown with percentages
   - Visual confidence bars

**Example Texts to Try:**
- "I'm so excited about this amazing opportunity!"
- "This is absolutely terrible and disappointing."
- "I'm worried about the upcoming presentation."
- "What a wonderful surprise this is!"

### 3. Emotion Timeline Visualization

**Features:**
- Green line: Facial emotions over time
- Blue line: Text sentiment over time
- X-axis: Time in seconds since session start
- Y-axis: Different emotion categories
- Updates automatically every 5 detections

### 4. Session Statistics

**Displays:**
- Total number of detections
- Breakdown: Facial vs Text analyses
- Dominant emotions for each modality
- Frequency counts

---

## 🔍 Troubleshooting

### Camera Not Working

**Issue**: "Unable to access camera" error

**Solutions:**
```bash
# Check camera permissions (Windows)
# Settings → Privacy → Camera → Allow desktop apps

# Test camera with OpenCV
python -c "import cv2; cap = cv2.VideoCapture(0); print('Camera working!' if cap.isOpened() else 'Camera not accessible')"

# Try different camera index
# Edit line in code: self.cap = cv2.VideoCapture(1)  # Try 1, 2, etc.
```

### Model Loading Errors

**Issue**: "Error loading text model" or transformation errors

**Solutions:**
```bash
# Clear cache and reinstall transformers
pip uninstall transformers -y
pip cache purge
pip install transformers

# Manually download model
python -c "from transformers import AutoTokenizer, AutoModelForSequenceClassification; AutoTokenizer.from_pretrained('j-hartmann/emotion-english-distilroberta-base'); AutoModelForSequenceClassification.from_pretrained('j-hartmann/emotion-english-distilroberta-base')"
```

### DeepFace Issues

**Issue**: Face detection not working or errors

**Solutions:**
```bash
# Reinstall DeepFace
pip uninstall deepface -y
pip install deepface

# Clear DeepFace home directory
# Windows: Delete C:\Users\YourName\.deepface
# macOS/Linux: Delete ~/.deepface

# Manually initialize
python -c "from deepface import DeepFace; DeepFace.build_model('Emotion')"
```

### Performance Issues

**Slow Processing:**
- Reduce frame processing rate (increase `time.sleep()` value in `process_frames`)
- Close other applications
- Use GPU if available (check PyTorch installation)

**High Memory Usage:**
- Reduce `emotion_history` maxlen (default: 50)
- Clear history periodically
- Restart application

### GUI Display Issues

**Blurry or Scaled Incorrectly:**
```bash
# Windows: Disable DPI scaling
# Right-click python.exe → Properties → Compatibility → 
# "Override high DPI scaling behavior"
```

---

## 🚀 Advanced Usage

### Custom Emotion Mapping

Edit the emotion mapping dictionary to customize emotion labels:

```python
emotion_mapping = {
    'angry': 0, 'disgust': 1, 'fear': 2, 'happy': 3,
    'sad': 4, 'surprise': 5, 'neutral': 6,
    # Add custom mappings
}
```

### Export Session Data

Add this method to save emotion history:

```python
def export_session(self):
    """Export emotion history to JSON"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"emotion_session_{timestamp}.json"
    
    data = {
        'session_start': datetime.fromtimestamp(self.emotion_history[0]['timestamp']).isoformat(),
        'total_detections': len(self.emotion_history),
        'emotions': list(self.emotion_history)
    }
    
    with open(filename, 'w') as f:
        json.dump(data, f, indent=2)
    
    print(f"Session exported to {filename}")
```

### Using Different Models

**For Text Analysis:**
```python
# Alternative models:
# Sentiment: "cardiffnlp/twitter-roberta-base-sentiment"
# Emotion: "SamLowe/roberta-base-go_emotions"
# Multilingual: "xlm-roberta-base"

self.text_model_name = "YOUR_PREFERRED_MODEL"
```

**For Face Analysis:**
```python
# DeepFace supports multiple backends:
# 'opencv', 'ssd', 'dlib', 'mtcnn', 'retinaface', 'mediapipe'

result = DeepFace.analyze(frame, actions=['emotion'],
                         detector_backend='retinaface',  # Change here
                         enforce_detection=False, silent=True)
```

### Batch Processing

Process multiple images or text files:

```python
def batch_process_images(self, image_folder):
    """Process all images in a folder"""
    results = []
    for img_file in os.listdir(image_folder):
        if img_file.endswith(('.jpg', '.png', '.jpeg')):
            img_path = os.path.join(image_folder, img_file)
            img = cv2.imread(img_path)
            result = DeepFace.analyze(img, actions=['emotion'], 
                                    enforce_detection=False, silent=True)
            results.append({'file': img_file, 'result': result})
    return results
```

---

## 📊 Performance Optimization

### GPU Acceleration

```bash
# Install CUDA-enabled PyTorch (NVIDIA GPU)
pip uninstall torch
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118

# Verify GPU usage
python -c "import torch; print(f'GPU Available: {torch.cuda.is_available()}')"
```

### Reduce Model Size

```python
# Use quantized models for faster inference
from transformers import AutoModelForSequenceClassification
import torch

model = AutoModelForSequenceClassification.from_pretrained(
    "j-hartmann/emotion-english-distilroberta-base"
)
model = torch.quantization.quantize_dynamic(
    model, {torch.nn.Linear}, dtype=torch.qint8
)
```

---

## 📝 Dataset Information

### Training Data Sources

**Text Model (RoBERTa):**
- Trained on: Unified Emotion Dataset
- Languages: English
- Emotion categories: 7 (anger, disgust, fear, joy, neutral, sadness, surprise)
- Training samples: ~400k labeled examples

**Facial Model (DeepFace):**
- Trained on: FER2013, AffectNet, and other facial expression datasets
- Images: ~35k facial images
- Emotion categories: 7 (angry, disgust, fear, happy, sad, surprise, neutral)

### Creating Custom Datasets

For custom training:

```python
# Text dataset format (CSV)
# text,emotion
# "I love this!",joy
# "This is terrible",anger

# Image dataset structure
# dataset/
#   ├── angry/
#   │   ├── img1.jpg
#   │   └── img2.jpg
#   ├── happy/
#   └── ...
```

---

## 🤝 Contributing & Support

### Reporting Issues

If you encounter bugs:
1. Note your Python version: `python --version`
2. Check package versions: `pip list`
3. Include error messages and traceback
4. Describe steps to reproduce

### Feature Requests

Potential enhancements:
- Multi-face detection
- Voice emotion analysis
- Real-time emotion heatmaps
- Cross-modal emotion fusion
- Export to video with annotations

---

## 📄 License & Credits

**Models Used:**
- Text: [j-hartmann/emotion-english-distilroberta-base](https://huggingface.co/j-hartmann/emotion-english-distilroberta-base)
- Face: DeepFace library with multiple backend models

**Libraries:**
- Transformers (Hugging Face)
- DeepFace (serengil)
- OpenCV
- PyTorch
- TensorFlow

---

## 🎓 Learning Resources

**Understanding Emotions:**
- [Ekman's Basic Emotions](https://www.paulekman.com/universal-emotions/)
- [Emotion Recognition Research](https://arxiv.org/abs/2104.02041)

**Technical Deep Dives:**
- [Transformers for NLP](https://huggingface.co/course)
- [DeepFace Documentation](https://github.com/serengil/deepface)
- [OpenCV Tutorials](https://docs.opencv.org/master/d9/df8/tutorial_root.html)

---

**Happy Emotion Detecting! 🎭✨**