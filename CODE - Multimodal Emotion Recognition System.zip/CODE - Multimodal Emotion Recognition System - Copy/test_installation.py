"""
Installation Verification Script
Test all dependencies and system components
"""

import sys
import os

def print_header(text):
    """Print formatted header"""
    print("\n" + "=" * 60)
    print(f"  {text}")
    print("=" * 60)

def print_success(text):
    """Print success message"""
    print(f"✓ {text}")

def print_error(text):
    """Print error message"""
    print(f"✗ {text}")

def print_warning(text):
    """Print warning message"""
    print(f"⚠ {text}")

def test_python_version():
    """Check Python version"""
    print_header("Python Version Check")
    version = sys.version_info
    version_str = f"{version.major}.{version.minor}.{version.micro}"
    print(f"Python Version: {version_str}")
    
    if version.major == 3 and version.minor >= 8:
        print_success(f"Python {version_str} is compatible")
        return True
    else:
        print_error(f"Python {version_str} is not compatible. Requires Python 3.8+")
        return False

def test_imports():
    """Test all required imports"""
    print_header("Testing Package Imports")
    
    packages = {
        'cv2': 'OpenCV',
        'numpy': 'NumPy',
        'PIL': 'Pillow',
        'torch': 'PyTorch',
        'transformers': 'Transformers',
        'deepface': 'DeepFace',
        'matplotlib': 'Matplotlib',
        'pandas': 'Pandas',
        'sklearn': 'Scikit-learn'
    }
    
    all_passed = True
    
    for module, name in packages.items():
        try:
            if module == 'PIL':
                import PIL
                version = PIL.__version__
            elif module == 'sklearn':
                import sklearn
                version = sklearn.__version__
            else:
                exec(f"import {module}")
                version = eval(f"{module}.__version__")
            
            print_success(f"{name:20s} - Version {version}")
        except ImportError as e:
            print_error(f"{name:20s} - NOT INSTALLED")
            all_passed = False
        except Exception as e:
            print_warning(f"{name:20s} - Installed (version unknown)")
    
    return all_passed

def test_camera():
    """Test camera access"""
    print_header("Camera Access Test")
    
    try:
        import cv2
        cap = cv2.VideoCapture(0)
        
        if cap.isOpened():
            ret, frame = cap.read()
            if ret:
                print_success(f"Camera accessible - Resolution: {frame.shape[1]}x{frame.shape[0]}")
                cap.release()
                return True
            else:
                print_error("Camera opened but cannot read frames")
                cap.release()
                return False
        else:
            print_error("Cannot open camera")
            print("  Troubleshooting:")
            print("  1. Check if camera is connected")
            print("  2. Check camera permissions")
            print("  3. Try different camera index (0, 1, 2...)")
            return False
    except Exception as e:
        print_error(f"Camera test failed: {str(e)}")
        return False

def test_models():
    """Test model loading"""
    print_header("Model Loading Test")
    
    # Test text model
    print("\nTesting Text Sentiment Model...")
    try:
        from transformers import AutoTokenizer, AutoModelForSequenceClassification
        model_name = "j-hartmann/emotion-english-distilroberta-base"
        
        print("  Downloading/Loading tokenizer...")
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        print_success("Tokenizer loaded")
        
        print("  Downloading/Loading model...")
        model = AutoModelForSequenceClassification.from_pretrained(model_name)
        print_success("Model loaded")
        
        # Test inference
        print("  Testing inference...")
        from transformers import pipeline
        sentiment = pipeline("text-classification", model=model, tokenizer=tokenizer, top_k=None)
        result = sentiment("I am very happy today!")[0]
        print_success(f"Inference successful - Detected: {result[0]['label']}")
        
        text_model_ok = True
    except Exception as e:
        print_error(f"Text model test failed: {str(e)}")
        text_model_ok = False
    
    # Test DeepFace
    print("\nTesting DeepFace Model...")
    try:
        from deepface import DeepFace
        import numpy as np
        
        print("  Creating test image...")
        # Create a dummy face-like image
        test_img = np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
        
        print("  Loading DeepFace models (this may take a moment)...")
        try:
            result = DeepFace.analyze(test_img, actions=['emotion'], 
                                     enforce_detection=False, silent=True)
            print_success("DeepFace loaded and working")
            deepface_ok = True
        except Exception as e:
            print_warning(f"DeepFace analysis had issues: {str(e)}")
            print_warning("This might be normal for random test image")
            deepface_ok = True  # Don't fail on dummy image
            
    except Exception as e:
        print_error(f"DeepFace test failed: {str(e)}")
        deepface_ok = False
    
    return text_model_ok and deepface_ok

def test_gpu():
    """Test GPU availability"""
    print_header("GPU Availability Check")
    
    try:
        import torch
        
        if torch.cuda.is_available():
            gpu_count = torch.cuda.device_count()
            gpu_name = torch.cuda.get_device_name(0)
            print_success(f"GPU Available: {gpu_name}")
            print(f"  GPU Count: {gpu_count}")
            print(f"  CUDA Version: {torch.version.cuda}")
            return True
        else:
            print_warning("No GPU detected - will use CPU")
            print("  For better performance, consider installing CUDA-enabled PyTorch")
            print("  Visit: https://pytorch.org/get-started/locally/")
            return True  # Not a failure, just a warning
    except Exception as e:
        print_warning(f"GPU test inconclusive: {str(e)}")
        return True

def test_disk_space():
    """Check available disk space"""
    print_header("Disk Space Check")
    
    try:
        import shutil
        total, used, free = shutil.disk_usage("/")
        
        free_gb = free / (1024**3)
        print(f"Free Disk Space: {free_gb:.2f} GB")
        
        if free_gb < 5:
            print_warning(f"Low disk space. At least 5GB recommended")
            return False
        else:
            print_success(f"Sufficient disk space available")
            return True
    except Exception as e:
        print_warning(f"Could not check disk space: {str(e)}")
        return True

def test_tkinter():
    """Test Tkinter GUI"""
    print_header("GUI (Tkinter) Test")
    
    try:
        import tkinter as tk
        
        # Create and destroy a test window
        root = tk.Tk()
        root.withdraw()  # Hide the window
        root.destroy()
        
        print_success("Tkinter GUI library working")
        return True
    except Exception as e:
        print_error(f"Tkinter test failed: {str(e)}")
        print("  On Linux, install: sudo apt-get install python3-tk")
        return False

def run_sample_test():
    """Run a complete sample detection"""
    print_header("Sample Detection Test")
    
    try:
        from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
        import numpy as np
        
        # Text sentiment test
        print("\nTesting text sentiment analysis...")
        model_name = "j-hartmann/emotion-english-distilroberta-base"
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForSequenceClassification.from_pretrained(model_name)
        sentiment = pipeline("text-classification", model=model, tokenizer=tokenizer, top_k=None)
        
        test_texts = [
            "I am so happy and excited!",
            "This is terrible and sad.",
            "I'm worried and scared."
        ]
        
        for text in test_texts:
            result = sentiment(text)[0]
            top_emotion = result[0]
            print(f"  Text: '{text}'")
            print(f"    → Emotion: {top_emotion['label']} ({top_emotion['score']*100:.1f}%)")
        
        print_success("Text sentiment analysis working correctly")
        
        return True
        
    except Exception as e:
        print_error(f"Sample test failed: {str(e)}")
        return False

def main():
    """Run all tests"""
    print("\n" + "🎭" * 20)
    print("  MULTIMODAL EMOTION RECOGNITION SYSTEM")
    print("  Installation Verification Script")
    print("🎭" * 20)
    
    results = {}
    
    # Run all tests
    results['Python Version'] = test_python_version()
    results['Package Imports'] = test_imports()
    results['Camera Access'] = test_camera()
    results['Tkinter GUI'] = test_tkinter()
    results['GPU Support'] = test_gpu()
    results['Disk Space'] = test_disk_space()
    results['Model Loading'] = test_models()
    results['Sample Detection'] = run_sample_test()
    
    # Print summary
    print_header("VERIFICATION SUMMARY")
    
    all_passed = True
    for test_name, passed in results.items():
        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"{test_name:25s} : {status}")
        if not passed:
            all_passed = False
    
    print("\n" + "=" * 60)
    
    if all_passed:
        print("\n🎉 ALL TESTS PASSED! 🎉")
        print("\nYour system is ready to run the Emotion Recognition System!")
        print("\nRun the main application with:")
        print("  python emotion_recognition_system.py")
    else:
        print("\n⚠️  SOME TESTS FAILED")
        print("\nPlease fix the issues above before running the application.")
        print("\nCommon fixes:")
        print("  1. pip install -r requirements.txt")
        print("  2. Check camera permissions")
        print("  3. Ensure sufficient disk space")
        print("\nRefer to SETUP_AND_USAGE_GUIDE.md for detailed troubleshooting.")
    
    print("\n" + "=" * 60 + "\n")
    
    return all_passed

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)