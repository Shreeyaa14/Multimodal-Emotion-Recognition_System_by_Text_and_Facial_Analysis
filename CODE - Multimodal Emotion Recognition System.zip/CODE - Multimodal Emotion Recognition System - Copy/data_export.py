"""
Data Export and Analytics Module
For Multimodal Emotion Recognition System
"""

import json
import csv
from datetime import datetime
import os
import matplotlib.pyplot as plt
import numpy as np
from collections import Counter

class EmotionDataExporter:
    """Handle exporting and analyzing emotion data"""
    
    def __init__(self, output_dir="emotion_data"):
        self.output_dir = output_dir
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
    
    def export_to_json(self, emotion_history, filename=None):
        """Export emotion history to JSON file"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"emotion_session_{timestamp}.json"
        
        filepath = os.path.join(self.output_dir, filename)
        
        # Convert deque to list and prepare data
        data = {
            'metadata': {
                'export_date': datetime.now().isoformat(),
                'total_detections': len(emotion_history),
                'session_start': datetime.fromtimestamp(
                    emotion_history[0]['timestamp']
                ).isoformat() if emotion_history else None,
                'session_end': datetime.fromtimestamp(
                    emotion_history[-1]['timestamp']
                ).isoformat() if emotion_history else None
            },
            'emotions': []
        }
        
        for entry in emotion_history:
            emotion_entry = {
                'timestamp': datetime.fromtimestamp(entry['timestamp']).isoformat(),
                'type': entry['type'],
                'emotion': entry['emotion'],
                'confidence': entry['confidence']
            }
            if 'all_emotions' in entry:
                emotion_entry['all_emotions'] = entry['all_emotions']
            data['emotions'].append(emotion_entry)
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"✓ Data exported to {filepath}")
        return filepath
    
    def export_to_csv(self, emotion_history, filename=None):
        """Export emotion history to CSV file"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"emotion_session_{timestamp}.csv"
        
        filepath = os.path.join(self.output_dir, filename)
        
        with open(filepath, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Timestamp', 'Type', 'Emotion', 'Confidence'])
            
            for entry in emotion_history:
                writer.writerow([
                    datetime.fromtimestamp(entry['timestamp']).isoformat(),
                    entry['type'],
                    entry['emotion'],
                    entry['confidence']
                ])
        
        print(f"✓ Data exported to {filepath}")
        return filepath
    
    def generate_statistics(self, emotion_history):
        """Generate comprehensive statistics"""
        if not emotion_history:
            return {}
        
        face_emotions = [e for e in emotion_history if e['type'] == 'face']
        text_emotions = [e for e in emotion_history if e['type'] == 'text']
        
        stats = {
            'overall': {
                'total_detections': len(emotion_history),
                'face_detections': len(face_emotions),
                'text_detections': len(text_emotions),
                'duration_seconds': emotion_history[-1]['timestamp'] - emotion_history[0]['timestamp']
            },
            'facial': self._get_emotion_stats(face_emotions),
            'text': self._get_emotion_stats(text_emotions)
        }
        
        return stats
    
    def _get_emotion_stats(self, emotions):
        """Get statistics for a list of emotions"""
        if not emotions:
            return {}
        
        emotion_list = [e['emotion'] for e in emotions]
        confidence_list = [e['confidence'] for e in emotions]
        
        emotion_counts = Counter(emotion_list)
        
        return {
            'count': len(emotions),
            'unique_emotions': len(emotion_counts),
            'most_common': emotion_counts.most_common(3),
            'average_confidence': np.mean(confidence_list),
            'confidence_std': np.std(confidence_list),
            'emotion_distribution': dict(emotion_counts)
        }
    
    def generate_report(self, emotion_history, filename=None):
        """Generate a comprehensive text report"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"emotion_report_{timestamp}.txt"
        
        filepath = os.path.join(self.output_dir, filename)
        stats = self.generate_statistics(emotion_history)
        
        with open(filepath, 'w') as f:
            f.write("=" * 60 + "\n")
            f.write("MULTIMODAL EMOTION RECOGNITION REPORT\n")
            f.write("=" * 60 + "\n\n")
            
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            # Overall statistics
            f.write("OVERALL STATISTICS\n")
            f.write("-" * 60 + "\n")
            f.write(f"Total Detections: {stats['overall']['total_detections']}\n")
            f.write(f"Facial Detections: {stats['overall']['face_detections']}\n")
            f.write(f"Text Detections: {stats['overall']['text_detections']}\n")
            f.write(f"Session Duration: {stats['overall']['duration_seconds']:.1f} seconds\n\n")
            
            # Facial emotion statistics
            if stats['facial']:
                f.write("FACIAL EMOTION ANALYSIS\n")
                f.write("-" * 60 + "\n")
                f.write(f"Total Detections: {stats['facial']['count']}\n")
                f.write(f"Average Confidence: {stats['facial']['average_confidence']:.2f}%\n")
                f.write(f"Confidence Std Dev: {stats['facial']['confidence_std']:.2f}%\n\n")
                f.write("Top Emotions:\n")
                for emotion, count in stats['facial']['most_common']:
                    percentage = (count / stats['facial']['count']) * 100
                    f.write(f"  {emotion.capitalize()}: {count} times ({percentage:.1f}%)\n")
                f.write("\n")
            
            # Text emotion statistics
            if stats['text']:
                f.write("TEXT SENTIMENT ANALYSIS\n")
                f.write("-" * 60 + "\n")
                f.write(f"Total Analyses: {stats['text']['count']}\n")
                f.write(f"Average Confidence: {stats['text']['average_confidence']:.2f}%\n")
                f.write(f"Confidence Std Dev: {stats['text']['confidence_std']:.2f}%\n\n")
                f.write("Top Emotions:\n")
                for emotion, count in stats['text']['most_common']:
                    percentage = (count / stats['text']['count']) * 100
                    f.write(f"  {emotion.capitalize()}: {count} times ({percentage:.1f}%)\n")
                f.write("\n")
            
            f.write("=" * 60 + "\n")
            f.write("End of Report\n")
            f.write("=" * 60 + "\n")
        
        print(f"✓ Report generated at {filepath}")
        return filepath
    
    def create_visualizations(self, emotion_history, filename_prefix=None):
        """Create comprehensive visualizations"""
        if not emotion_history:
            print("No data to visualize")
            return
        
        if filename_prefix is None:
            filename_prefix = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # 1. Emotion distribution pie charts
        self._create_distribution_chart(emotion_history, filename_prefix)
        
        # 2. Confidence timeline
        self._create_confidence_timeline(emotion_history, filename_prefix)
        
        # 3. Emotion frequency bar chart
        self._create_frequency_chart(emotion_history, filename_prefix)
        
        print(f"✓ Visualizations created in {self.output_dir}")
    
    def _create_distribution_chart(self, emotion_history, prefix):
        """Create pie charts for emotion distribution"""
        face_emotions = [e['emotion'] for e in emotion_history if e['type'] == 'face']
        text_emotions = [e['emotion'] for e in emotion_history if e['type'] == 'text']
        
        fig, axes = plt.subplots(1, 2, figsize=(14, 6))
        
        if face_emotions:
            face_counts = Counter(face_emotions)
            axes[0].pie(face_counts.values(), labels=face_counts.keys(), autopct='%1.1f%%',
                       startangle=90, colors=plt.cm.Pastel1.colors)
            axes[0].set_title('Facial Emotion Distribution')
        else:
            axes[0].text(0.5, 0.5, 'No Facial Data', ha='center', va='center')
            axes[0].set_title('Facial Emotion Distribution')
        
        if text_emotions:
            text_counts = Counter(text_emotions)
            axes[1].pie(text_counts.values(), labels=text_counts.keys(), autopct='%1.1f%%',
                       startangle=90, colors=plt.cm.Pastel2.colors)
            axes[1].set_title('Text Sentiment Distribution')
        else:
            axes[1].text(0.5, 0.5, 'No Text Data', ha='center', va='center')
            axes[1].set_title('Text Sentiment Distribution')
        
        plt.tight_layout()
        filepath = os.path.join(self.output_dir, f"{prefix}_distribution.png")
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()
    
    def _create_confidence_timeline(self, emotion_history, prefix):
        """Create confidence score timeline"""
        base_time = emotion_history[0]['timestamp']
        
        face_times = [(e['timestamp'] - base_time, e['confidence']) 
                     for e in emotion_history if e['type'] == 'face']
        text_times = [(e['timestamp'] - base_time, e['confidence']) 
                     for e in emotion_history if e['type'] == 'text']
        
        plt.figure(figsize=(12, 6))
        
        if face_times:
            times, confidences = zip(*face_times)
            plt.plot(times, confidences, 'o-', label='Facial', alpha=0.7, linewidth=2)
        
        if text_times:
            times, confidences = zip(*text_times)
            plt.plot(times, confidences, 's-', label='Text', alpha=0.7, linewidth=2)
        
        plt.xlabel('Time (seconds)')
        plt.ylabel('Confidence (%)')
        plt.title('Confidence Scores Over Time')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        filepath = os.path.join(self.output_dir, f"{prefix}_confidence_timeline.png")
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()
    
    def _create_frequency_chart(self, emotion_history, prefix):
        """Create bar chart for emotion frequencies"""
        face_emotions = [e['emotion'] for e in emotion_history if e['type'] == 'face']
        text_emotions = [e['emotion'] for e in emotion_history if e['type'] == 'text']
        
        fig, axes = plt.subplots(2, 1, figsize=(12, 10))
        
        if face_emotions:
            face_counts = Counter(face_emotions)
            emotions, counts = zip(*sorted(face_counts.items()))
            axes[0].bar(emotions, counts, color='skyblue', edgecolor='navy', alpha=0.7)
            axes[0].set_title('Facial Emotion Frequencies')
            axes[0].set_ylabel('Count')
            axes[0].grid(True, alpha=0.3, axis='y')
        else:
            axes[0].text(0.5, 0.5, 'No Facial Data', ha='center', va='center',
                        transform=axes[0].transAxes)
            axes[0].set_title('Facial Emotion Frequencies')
        
        if text_emotions:
            text_counts = Counter(text_emotions)
            emotions, counts = zip(*sorted(text_counts.items()))
            axes[1].bar(emotions, counts, color='lightcoral', edgecolor='darkred', alpha=0.7)
            axes[1].set_title('Text Sentiment Frequencies')
            axes[1].set_ylabel('Count')
            axes[1].set_xlabel('Emotion')
            axes[1].grid(True, alpha=0.3, axis='y')
        else:
            axes[1].text(0.5, 0.5, 'No Text Data', ha='center', va='center',
                        transform=axes[1].transAxes)
            axes[1].set_title('Text Sentiment Frequencies')
        
        plt.tight_layout()
        filepath = os.path.join(self.output_dir, f"{prefix}_frequencies.png")
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()

# Example usage
if __name__ == "__main__":
    # This would typically be called from the main application
    # Example:
    # exporter = EmotionDataExporter()
    # exporter.export_to_json(emotion_history)
    # exporter.export_to_csv(emotion_history)
    # exporter.generate_report(emotion_history)
    # exporter.create_visualizations(emotion_history)
    
    print("Data Export Module Loaded")
    print("Use EmotionDataExporter class to export and analyze emotion data")