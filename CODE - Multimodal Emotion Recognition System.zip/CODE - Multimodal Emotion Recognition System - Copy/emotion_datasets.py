"""
Comprehensive Emotion Datasets
Contains extensive vocabulary and patterns for emotion recognition
"""

class EmotionDatasets:
    """Comprehensive emotion datasets for text and facial recognition"""
    
    def __init__(self):
        self.emotion_words = {
            'happy': {
                'words': [
                    'happy', 'joyful', 'delighted', 'pleased', 'glad', 'cheerful', 'merry',
                    'jovial', 'jolly', 'ecstatic', 'euphoric', 'elated', 'enthusiastic',
                    'excited', 'thrilled', 'overjoyed', 'content', 'satisfied', 'pleased',
                    'optimistic', 'positive', 'upbeat', 'lively', 'vibrant', 'radiant',
                    'blissful', 'gleeful', 'joyous', 'exuberant', 'buoyant', 'sunny',
                    'bright', 'cheery', 'festive', 'celebratory', 'triumphant', 'victorious',
                    'proud', 'accomplished', 'successful', 'grateful', 'thankful', 'blessed',
                    'fortunate', 'lucky', 'hopeful', 'confident', 'energetic', 'spirited'
                ],
                'intensifiers': ['very', 'extremely', 'incredibly', 'absolutely', 'completely', 'totally', 'really', 'so'],
                'patterns': [
                    r'i feel (?:very|extremely|so) (?:happy|joyful|glad)',
                    r'(?:this|that) makes me (?:happy|excited|thrilled)',
                    r'i\'m (?:so|very) (?:happy|pleased|excited)',
                    r'feeling (?:great|wonderful|amazing|fantastic)',
                    r'can\'t stop (?:smiling|laughing|feeling happy)'
                ],
                'weight': 1.0
            },
            
            'sad': {
                'words': [
                    'sad', 'unhappy', 'miserable', 'depressed', 'down', 'blue', 'gloomy',
                    'melancholy', 'somber', 'dejected', 'despondent', 'disheartened',
                    'disappointed', 'let down', 'crushed', 'devastated', 'heartbroken',
                    'grieving', 'sorrowful', 'mournful', 'regretful', 'ashamed', 'embarrassed',
                    'lonely', 'isolated', 'empty', 'hollow', 'numb', 'apathetic', 'listless',
                    'weary', 'exhausted', 'drained', 'hopeless', 'despair', 'desperate',
                    'miserable', 'wretched', 'pathetic', 'inadequate', 'worthless', 'useless'
                ],
                'intensifiers': ['very', 'extremely', 'deeply', 'terribly', 'awfully', 'incredibly', 'so'],
                'patterns': [
                    r'i feel (?:so|very|extremely) (?:sad|depressed|miserable)',
                    r'(?:this|that) makes me (?:sad|depressed|unhappy)',
                    r'i\'m (?:so|very) (?:sad|heartbroken|disappointed)',
                    r'feeling (?:down|blue|gloomy|miserable)',
                    r'can\'t help (?:crying|feeling sad|being sad)'
                ],
                'weight': 1.0
            },
            
            'angry': {
                'words': [
                    'angry', 'mad', 'furious', 'enraged', 'irate', 'livid', 'outraged',
                    'infuriated', 'annoyed', 'irritated', 'frustrated', 'aggravated',
                    'exasperated', 'indignant', 'resentful', 'bitter', 'hostile', 'aggressive',
                    'violent', 'destructive', 'vengeful', 'spiteful', 'malicious', 'cruel',
                    'outraged', 'appalled', 'disgusted', 'revolted', 'repulsed', 'sickened',
                    'fuming', 'seething', 'boiling', 'burning', 'incensed', 'enraged',
                    'irate', 'wrathful', 'furious', 'livid', 'apoplectic', 'ballistic'
                ],
                'intensifiers': ['very', 'extremely', 'incredibly', 'absolutely', 'completely', 'totally', 'so', 'fucking'],
                'patterns': [
                    r'i\'m (?:so|very|extremely) (?:angry|mad|furious)',
                    r'(?:this|that) makes me (?:angry|furious|enraged)',
                    r'i can\'t believe (?:this|that) (?:makes me so angry)',
                    r'feeling (?:furious|enraged|infuriated)',
                    r'(?:absolutely|completely) (?:furious|enraged|livid)'
                ],
                'weight': 1.0
            },
            
            'fear': {
                'words': [
                    'afraid', 'scared', 'frightened', 'terrified', 'fearful', 'anxious',
                    'worried', 'concerned', 'nervous', 'apprehensive', 'panicked', 'alarmed',
                    'startled', 'shocked', 'stunned', 'horrified', 'petrified', 'paralyzed',
                    'intimidated', 'threatened', 'vulnerable', 'exposed', 'insecure', 'unsafe',
                    'endangered', 'at risk', 'in danger', 'perilous', 'hazardous', 'risky',
                    'uncertain', 'doubtful', 'skeptical', 'suspicious', 'wary', 'cautious',
                    'timid', 'shy', 'bashful', 'hesitant', 'reluctant', 'uneasy', 'unsettled'
                ],
                'intensifiers': ['very', 'extremely', 'incredibly', 'absolutely', 'completely', 'totally', 'so', 'deathly'],
                'patterns': [
                    r'i\'m (?:so|very|extremely) (?:scared|afraid|frightened)',
                    r'(?:this|that) (?:scares|frightens|terrifies) me',
                    r'feeling (?:terrified|petrified|paralyzed)',
                    r'i\'m (?:deathly|extremely) (?:afraid|scared)',
                    r'can\'t help (?:feeling scared|being afraid)'
                ],
                'weight': 1.0
            },
            
            'surprise': {
                'words': [
                    'surprised', 'amazed', 'astonished', 'astounded', 'shocked', 'stunned',
                    'bewildered', 'confused', 'perplexed', 'puzzled', 'baffled', 'mystified',
                    'dumbfounded', 'flabbergasted', 'speechless', 'awestruck', 'wonderstruck',
                    'incredulous', 'skeptical', 'doubtful', 'unbelieving', 'startled', 'taken aback',
                    'caught off guard', 'unprepared', 'unexpected', 'sudden', 'abrupt', 'immediate',
                    'shocking', 'staggering', 'breathtaking', 'mind-blowing', 'unbelievable',
                    'extraordinary', 'remarkable', 'incredible', 'amazing', 'astonishing'
                ],
                'intensifiers': ['very', 'extremely', 'incredibly', 'absolutely', 'completely', 'totally', 'so', 'completely'],
                'patterns': [
                    r'i\'m (?:so|very|completely) (?:surprised|amazed|shocked)',
                    r'(?:this|that) (?:surprises|amazes|astonishes) me',
                    r'i can\'t believe (?:this|that)',
                    r'feeling (?:shocked|stunned|bewildered)',
                    r'(?:absolutely|completely) (?:amazed|astonished|flabbergasted)'
                ],
                'weight': 1.0
            },
            
            'disgust': {
                'words': [
                    'disgusted', 'revolted', 'repulsed', 'sickened', 'nauseated', 'appalled',
                    'horrified', 'outraged', 'offended', 'insulted', 'displeased', 'annoyed',
                    'irritated', 'frustrated', 'disappointed', 'let down', 'dissatisfied',
                    'unhappy', 'miserable', 'contemptuous', 'scornful', 'disdainful', 'derisive',
                    'sarcastic', 'cynical', 'mocking', 'ridiculing', 'dismissive', 'rejecting',
                    'refusing', 'denying', 'opposing', 'resisting', 'protesting', 'objecting',
                    'complaining', 'criticizing', 'condemning', 'denouncing', 'cursing', 'swearing'
                ],
                'intensifiers': ['very', 'extremely', 'incredibly', 'absolutely', 'completely', 'totally', 'so', 'thoroughly'],
                'patterns': [
                    r'i\'m (?:so|very|extremely) (?:disgusted|revolted|appalled)',
                    r'(?:this|that) (?:disgusts|revolts|sickens) me',
                    r'feeling (?:disgusted|repulsed|nauseated)',
                    r'i (?:absolutely|completely) (?:disgust|hate) (?:this|that)',
                    r'(?:thoroughly|completely) (?:disgusted|revolted)'
                ],
                'weight': 1.0
            },
            
            'neutral': {
                'words': [
                    'neutral', 'calm', 'peaceful', 'relaxed', 'serene', 'tranquil', 'composed',
                    'collected', 'poised', 'balanced', 'stable', 'steady', 'even-tempered',
                    'unemotional', 'impassive', 'unconcerned', 'indifferent', 'detached',
                    'objective', 'unbiased', 'impartial', 'fair', 'reasonable', 'rational',
                    'logical', 'practical', 'matter-of-fact', 'straightforward', 'direct',
                    'honest', 'sincere', 'genuine', 'authentic', 'real', 'normal', 'typical'
                ],
                'intensifiers': ['very', 'quite', 'rather', 'fairly', 'reasonably', 'relatively'],
                'patterns': [
                    r'i feel (?:quite|very|fairly) (?:neutral|calm|relaxed)',
                    r'feeling (?:neutral|balanced|stable)',
                    r'i\'m (?:quite|fairly) (?:calm|relaxed|composed)',
                    r'(?:everything|nothing) seems (?:normal|fine|okay)',
                    r'feeling (?:neither|nor) (?:happy|sad)'
                ],
                'weight': 0.5
            }
        }
        
        self.emotion_colors = {
            'happy': '#4CAF50',
            'sad': '#2196F3', 
            'angry': '#F44336',
            'fear': '#FF9800',
            'surprise': '#FFEB3B',
            'disgust': '#9C27B0',
            'neutral': '#9E9E9E'
        }
        
        self.emotion_emojis = {
            'happy': '😊',
            'sad': '😢',
            'angry': '😠',
            'fear': '😨',
            'surprise': '😲',
            'disgust': '🤢',
            'neutral': '😐'
        }
    
    def get_emotion_words(self, emotion):
        """Get all words for a specific emotion"""
        return self.emotion_words.get(emotion, {}).get('words', [])
    
    def get_all_emotion_words(self):
        """Get all emotion words mapped to their emotions"""
        emotion_map = {}
        for emotion, data in self.emotion_words.items():
            for word in data['words']:
                emotion_map[word.lower()] = emotion
        return emotion_map
    
    def get_emotion_patterns(self, emotion):
        """Get regex patterns for a specific emotion"""
        return self.emotion_words.get(emotion, {}).get('patterns', [])
    
    def get_emotion_intensifiers(self, emotion):
        """Get intensifiers for a specific emotion"""
        return self.emotion_words.get(emotion, {}).get('intensifiers', [])
    
    def get_emotion_weight(self, emotion):
        """Get weight for a specific emotion"""
        return self.emotion_words.get(emotion, {}).get('weight', 1.0)
    
    def get_emotion_color(self, emotion):
        """Get color for a specific emotion"""
        return self.emotion_colors.get(emotion, '#9E9E9E')
    
    def get_emotion_emoji(self, emotion):
        """Get emoji for a specific emotion"""
        return self.emotion_emojis.get(emotion, '😐')
    
    def get_all_emotions(self):
        """Get list of all available emotions"""
        return list(self.emotion_words.keys())
    
    def create_training_data(self):
        """Create training data examples for each emotion"""
        training_data = []
        
        examples = {
            'happy': [
                "I am so happy today!",
                "This makes me feel joyful and excited.",
                "I'm feeling absolutely wonderful!",
                "Life is great and I feel blessed.",
                "I can't stop smiling because I'm so happy.",
                "This is the best day ever!",
                "I'm feeling cheerful and optimistic.",
                "Everything is going perfectly!",
                "I'm so grateful for this opportunity.",
                "Feeling ecstatic and full of joy!"
            ],
            'sad': [
                "I feel so sad and lonely.",
                "This makes me feel depressed and hopeless.",
                "I'm feeling miserable and disappointed.",
                "Everything seems to be going wrong.",
                "I can't help feeling sad and empty.",
                "This is breaking my heart.",
                "I feel so let down and discouraged.",
                "Nothing seems to matter anymore.",
                "I'm feeling so gloomy and dejected.",
                "I wish things were different."
            ],
            'angry': [
                "I'm so angry about this situation!",
                "This makes me furious and enraged.",
                "I can't believe how infuriating this is!",
                "I'm absolutely livid right now.",
                "This is completely unacceptable!",
                "I feel so frustrated and annoyed.",
                "I'm outraged by what happened.",
                "This makes my blood boil!",
                "I'm fuming with anger.",
                "I can't stand this anymore!"
            ],
            'fear': [
                "I'm so scared and worried.",
                "This terrifies me completely.",
                "I'm feeling anxious and nervous.",
                "I'm afraid of what might happen.",
                "This makes me feel so vulnerable.",
                "I'm terrified and can't stop shaking.",
                "I'm worried sick about this.",
                "This is making me panic.",
                "I feel so insecure and frightened.",
                "I'm scared to death!"
            ],
            'surprise': [
                "I'm completely surprised by this!",
                "Wow! I can't believe this happened!",
                "This is absolutely astonishing!",
                "I'm shocked and amazed!",
                "I never expected this to happen!",
                "This is completely unexpected!",
                "I'm blown away by this news!",
                "I'm speechless and stunned!",
                "This is mind-blowing!",
                "I can hardly believe my eyes!"
            ],
            'disgust': [
                "This is absolutely disgusting!",
                "I'm revolted by what I see.",
                "This makes me sick to my stomach.",
                "I'm completely appalled by this.",
                "This is repulsive and offensive.",
                "I feel nauseated just thinking about it.",
                "This is completely unacceptable!",
                "I'm horrified by this behavior.",
                "This makes me want to throw up.",
                "I'm thoroughly disgusted!"
            ],
            'neutral': [
                "I feel calm and balanced.",
                "Everything seems normal today.",
                "I'm feeling quite neutral about this.",
                "I'm composed and relaxed.",
                "Things are going as expected.",
                "I feel steady and peaceful.",
                "I'm neither happy nor sad.",
                "Everything seems fine and normal.",
                "I'm feeling quite calm today.",
                "Things are just okay."
            ]
        }
        
        for emotion, texts in examples.items():
            for text in texts:
                training_data.append({'text': text, 'emotion': emotion})
        
        return training_data
