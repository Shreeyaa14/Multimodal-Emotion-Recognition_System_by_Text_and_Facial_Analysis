# 🚀 Quick Start Guide
## Get Running in 5 Minutes!

---

## ⚡ Super Quick Installation (Windows)

Open Command Prompt and run:

```bash
# 1. Navigate to project folder
cd path\to\emotion-recognition-system

# 2. Create virtual environment
python -m venv venv

# 3. Activate it
venv\Scripts\activate

# 4. Install everything
pip install -r requirements.txt

# 5. Test installation
python test_installation.py

# 6. Run the app!
python emotion_recognition_system.py
```

---

## ⚡ Super Quick Installation (macOS/Linux)

Open Terminal and run:

```bash
# 1. Navigate to project folder
cd path/to/emotion-recognition-system

# 2. Create virtual environment
python3 -m venv venv

# 3. Activate it
source venv/bin/activate

# 4. Install everything
pip install -r requirements.txt

# 5. Test installation
python test_installation.py

# 6. Run the app!
python emotion_recognition_system.py
```

---

## 🎯 First Time Usage

### Step 1: Start the Application
When you run `python emotion_recognition_system.py`:
- **First launch**: Wait 1-2 minutes while models download (only happens once!)
- **Subsequent launches**: Opens in ~10 seconds

### Step 2: Try Facial Emotion Detection
1. Click **"▶ Start Camera"**
2. Look at your webcam
3. Make different facial expressions
4. Watch emotions update in real-time!

### Step 3: Try Text Sentiment Analysis
1. Type in the text box: `"I'm so happy and excited!"`
2. Click **"🔍 Analyze Text"**
3. See the emotion breakdown

### Step 4: View Your Analytics
- Check the **Emotion Timeline** graph (bottom right)
- Review **Session Statistics** for patterns

---

## 🆘 Quick Fixes

### Camera Not Working?
```bash
# Try this first:
python -c "import cv2; cap = cv2.VideoCapture(0); print('OK' if cap.isOpened() else 'FAIL')"

# If FAIL, check:
# 1. Is webcam connected?
# 2. Camera permissions enabled?
# 3. Try different number: cv2.VideoCapture(1) or (2)
```

### Installation Failed?
```bash
# Update pip first:
pip install --upgrade pip

# Then try again:
pip install -r requirements.txt

# Still failing? Install one by one:
pip install torch
pip install transformers
pip install opencv-python
pip install deepface
pip install pillow matplotlib pandas scikit-learn
```

### Models Won't Download?
```bash
# Manual download:
python -c "from transformers import AutoTokenizer, AutoModelForSequenceClassification; AutoTokenizer.from_pretrained('j-hartmann/emotion-english-distilroberta-base'); AutoModelForSequenceClassification.from_pretrained('j-hartmann/emotion-english-distilroberta-base')"
```

---

## 📝 Example Texts to Try

Copy and paste these into the text box:

**Happy:**
```
I'm so excited about this amazing opportunity! This is the best day ever!
```

**Sad:**
```
I feel so lonely and disappointed. Nothing seems to go right anymore.
```

**Angry:**
```
This is absolutely unacceptable and infuriating! I've had enough of this!
```

**Fear:**
```
I'm really worried and scared about what might happen tomorrow.
```

**Surprise:**
```
Wow! I can't believe this happened! This is completely unexpected!
```

---

## 🎨 Fun Things to Try

1. **Make Funny Faces** - See which emotion registers highest
2. **Test Song Lyrics** - Analyze your favorite songs
3. **Compare Moods** - Track your emotions throughout the day
4. **Test Movie Reviews** - Copy reviews and see sentiment
5. **Group Activity** - Have friends make faces, compare results!

---

## 📊 Export Your Data

After using the app, export your session:

```python
# Add this to emotion_recognition_system.py (at the end):
from data_export import EmotionDataExporter

exporter = EmotionDataExporter()
exporter.export_to_json(app.emotion_history)
exporter.generate_report(app.emotion_history)
exporter.create_visualizations(app.emotion_history)
```

---

## 🎓 Next Steps

Once you're comfortable:

1. **Read Full Documentation**: Check `SETUP_AND_USAGE_GUIDE.md`
2. **Try Batch Processing**: Process multiple files with `batch_processor.py`
3. **Customize Settings**: Modify detection parameters
4. **Export Analytics**: Generate reports and visualizations

---

## 💡 Pro Tips

- **Better Lighting** = Better face detection
- **Look Directly at Camera** for most accurate results
- **Longer Text** = More accurate sentiment analysis
- **Good Internet** needed for first-time model download
- **Close Other Apps** for better performance

---

## ❓ Need Help?

1. **Run Tests**: `python test_installation.py`
2. **Check Guide**: `SETUP_AND_USAGE_GUIDE.md`
3. **Read README**: `README.md`
4. **Troubleshooting**: See detailed guide in setup docs

---

**That's it! You're ready to detect emotions! 🎭✨**

Happy emotion recognizing!