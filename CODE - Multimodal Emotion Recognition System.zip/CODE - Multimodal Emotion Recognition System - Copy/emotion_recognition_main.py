"""
Multimodal Emotion Recognition System
Real-time Text Sentiment and Facial Emotion Analysis
Author: AI Assistant
Version: 1.0
"""

import cv2
import numpy as np
import os

os.environ.setdefault('TRANSFORMERS_NO_TF', '1')
os.environ.setdefault('USE_TF', '0')
os.environ.setdefault('USE_FLAX', '0')

from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
from PIL import Image, ImageTk
import threading
import queue
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import time
from collections import deque
import json
from datetime import datetime
import re
from typing import Any, Dict, List, Optional, Tuple

class MultimodalEmotionRecognizer:
    def __init__(self):
        """Initialize the emotion recognition system"""
        self.setup_models()
        self.setup_ui()
        self.emotion_history = deque(maxlen=50)
        self.face_smoothing_window = deque(maxlen=7)
        self.latest_face = None
        self.latest_text = None
        self.latest_fused = None
        self.running = False
        self.frame_queue = queue.Queue(maxsize=2)
        self.result_queue = queue.Queue()
        
        # Emotion mappings and colors
        self.emotion_colors = {
            'angry': '#FF4444', 'disgust': '#9C27B0', 'fear': '#FF9800',
            'happy': '#4CAF50', 'sad': '#2196F3', 'surprise': '#FFEB3B',
            'neutral': '#9E9E9E', 'positive': '#4CAF50', 'negative': '#F44336'
        }

        self.common_emotions = ('anger', 'disgust', 'fear', 'joy', 'sadness', 'surprise', 'neutral')
        self.face_to_common = {
            'angry': 'anger',
            'disgust': 'disgust',
            'fear': 'fear',
            'happy': 'joy',
            'sad': 'sadness',
            'surprise': 'surprise',
            'neutral': 'neutral',
        }
        
    def setup_models(self):
        """Initialize all ML models"""
        print("Loading models... This may take a moment.")

        self.DeepFace = None
        self.deepface_error = None
        try:
            from deepface import DeepFace  # type: ignore
            self.DeepFace = DeepFace
            print("✓ DeepFace loaded")
        except Exception as e:
            self.deepface_error = str(e)
            print(f"Error loading DeepFace/TensorFlow: {e}")
        
        # Text sentiment analysis - using RoBERTa-based emotion model
        try:
            self.text_model_name = "j-hartmann/emotion-english-distilroberta-base"
            self.text_tokenizer = AutoTokenizer.from_pretrained(self.text_model_name)
            self.text_model = AutoModelForSequenceClassification.from_pretrained(self.text_model_name)
            self.text_device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            self.text_model.to(self.text_device)
            self.text_model.eval()
            print("✓ Text sentiment model loaded")
        except Exception as e:
            print(f"Error loading text model: {e}")
            self.text_tokenizer = None
            self.text_model = None
            
        # Video capture
        self.cap = None

    def _clean_text(self, text: str) -> str:
        text = text.strip()
        text = re.sub(r"\s+", " ", text)
        return text

    def _ensure_common_distribution(self, probs: dict) -> dict:
        out = {k: 0.0 for k in self.common_emotions}
        for k, v in (probs or {}).items():
            if k in out:
                out[k] = float(v)
        total = sum(out.values())
        if total > 0:
            out = {k: v / total for k, v in out.items()}
        return out

    def _face_distribution_to_common(self, deepface_emotions: dict) -> dict:
        if not deepface_emotions:
            return {k: 0.0 for k in self.common_emotions}
        mapped = {k: 0.0 for k in self.common_emotions}
        for face_label, val in deepface_emotions.items():
            common = self.face_to_common.get(face_label)
            if common is not None:
                mapped[common] += float(val) / 100.0
        return self._ensure_common_distribution(mapped)

    def _pipeline_distribution_to_common(self, results: List[Dict[str, Any]]) -> Dict[str, float]:
        mapped = {k: 0.0 for k in self.common_emotions}
        for r in (results or []):
            label = str(r.get('label', '')).strip().lower()
            score = float(r.get('score', 0.0))
            if label in mapped:
                mapped[label] = score
        return self._ensure_common_distribution(mapped)

    def _predict_text_emotions(self, text: str) -> List[Dict[str, Any]]:
        if self.text_tokenizer is None or self.text_model is None:
            raise RuntimeError("Text model not loaded")
        inputs = self.text_tokenizer(
            text,
            return_tensors='pt',
            truncation=True,
            padding=True,
            max_length=256,
        )
        inputs = {k: v.to(self.text_device) for k, v in inputs.items()}
        with torch.no_grad():
            outputs = self.text_model(**inputs)
            logits = outputs.logits
            probs = torch.softmax(logits, dim=-1).squeeze(0)

        id2label = getattr(self.text_model.config, 'id2label', None) or {}
        results: List[Dict[str, Any]] = []
        for idx in range(int(probs.shape[-1])):
            label = str(id2label.get(idx, str(idx))).strip().lower()
            score = float(probs[idx].item())
            results.append({'label': label, 'score': score})
        return results

    def _dominant_from_distribution(self, dist: Dict[str, float]) -> Tuple[str, float]:
        if not dist:
            return 'neutral', 0.0
        emotion = max(dist.items(), key=lambda x: x[1])[0]
        return emotion, float(dist.get(emotion, 0.0))

    def _fuse(self, face_common: Optional[Dict[str, float]], text_common: Optional[Dict[str, float]]) -> Dict[str, Any]:
        face_w = float(self.face_weight_var.get()) if hasattr(self, 'face_weight_var') else 0.6
        text_w = float(self.text_weight_var.get()) if hasattr(self, 'text_weight_var') else 0.4
        if face_w < 0:
            face_w = 0.0
        if text_w < 0:
            text_w = 0.0

        face_common = self._ensure_common_distribution(face_common or {})
        text_common = self._ensure_common_distribution(text_common or {})

        if sum(face_common.values()) == 0 and sum(text_common.values()) == 0:
            fused = {k: 0.0 for k in self.common_emotions}
        else:
            fused = {k: (face_w * face_common.get(k, 0.0) + text_w * text_common.get(k, 0.0)) for k in self.common_emotions}
            fused = self._ensure_common_distribution(fused)

        dom, conf = self._dominant_from_distribution(fused)
        agreement = None
        if self.latest_face and self.latest_text:
            agreement = (self.latest_face.get('dominant_common') == self.latest_text.get('dominant_common'))

        return {
            'face_weight': face_w,
            'text_weight': text_w,
            'distribution': fused,
            'dominant_emotion': dom,
            'confidence': conf,
            'agreement': agreement,
        }
        
    def setup_ui(self):
        """Create the user interface"""
        self.root = tk.Tk()
        self.root.title("Multimodal Emotion Recognition System")
        self.root.geometry("1400x900")
        self.root.configure(bg='#1e1e1e')

        boot_label = tk.Label(
            self.root,
            text="Loading UI...",
            font=('Segoe UI', 14, 'bold'),
            bg='#1e1e1e',
            fg='#FFD700'
        )
        boot_label.place(relx=0.5, rely=0.02, anchor='n')
        self.root.update_idletasks()

        
        # Style configuration
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TFrame', background='#1e1e1e')
        style.configure('TLabel', background='#1e1e1e', foreground='white', font=('Segoe UI', 10))
        style.configure('Title.TLabel', font=('Segoe UI', 16, 'bold'))
        style.configure('TButton', font=('Segoe UI', 10), padding=10)
        
        # Main container
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        
        # Title
        title = ttk.Label(main_frame, text="Multimodal Emotion Recognition", style='Title.TLabel')
        title.grid(row=0, column=0, columnspan=2, pady=10)
        
        # Left panel - Video and controls
        left_panel = ttk.Frame(main_frame)
        left_panel.grid(row=1, column=0, padx=10, sticky=(tk.N, tk.S, tk.W, tk.E))
        
        # Video frame
        self.video_label = tk.Label(left_panel, bg='black', width=640, height=480)
        self.video_label.grid(row=0, column=0, pady=10)
        
        # Control buttons
        btn_frame = ttk.Frame(left_panel)
        btn_frame.grid(row=1, column=0, pady=10)
        
        self.start_btn = tk.Button(btn_frame, text="Start Camera", command=self.start_camera,
                                   bg='#4CAF50', fg='white', font=('Segoe UI', 11, 'bold'),
                                   padx=20, pady=10, relief=tk.FLAT)
        self.start_btn.grid(row=0, column=0, padx=5)
        
        self.stop_btn = tk.Button(btn_frame, text="Stop Camera", command=self.stop_camera,
                                  bg='#F44336', fg='white', font=('Segoe UI', 11, 'bold'),
                                  padx=20, pady=10, relief=tk.FLAT, state=tk.DISABLED)
        self.stop_btn.grid(row=0, column=1, padx=5)

        # Face model controls
        face_ctrl_frame = ttk.Frame(left_panel)
        face_ctrl_frame.grid(row=3, column=0, pady=10, sticky=(tk.W, tk.E))
        ttk.Label(face_ctrl_frame, text="Face Detector:", font=('Segoe UI', 10, 'bold')).grid(row=0, column=0, sticky=tk.W)
        self.detector_backend_var = tk.StringVar(value='retinaface')
        self.detector_backend_combo = ttk.Combobox(
            face_ctrl_frame,
            textvariable=self.detector_backend_var,
            values=['retinaface', 'mtcnn', 'opencv', 'ssd', 'dlib', 'mediapipe'],
            width=18,
            state='readonly'
        )
        self.detector_backend_combo.grid(row=0, column=1, padx=8, sticky=tk.W)

        ttk.Label(face_ctrl_frame, text="Face Weight:", font=('Segoe UI', 10, 'bold')).grid(row=0, column=2, padx=(20, 0), sticky=tk.W)
        self.face_weight_var = tk.DoubleVar(value=0.6)
        self.face_weight_scale = tk.Scale(
            face_ctrl_frame,
            from_=0.0,
            to=1.0,
            resolution=0.05,
            orient=tk.HORIZONTAL,
            variable=self.face_weight_var,
            length=180,
            bg='#1e1e1e',
            fg='white',
            highlightthickness=0,
        )
        self.face_weight_scale.grid(row=0, column=3, padx=8, sticky=tk.W)

        ttk.Label(face_ctrl_frame, text="Text Weight:", font=('Segoe UI', 10, 'bold')).grid(row=1, column=2, padx=(20, 0), sticky=tk.W)
        self.text_weight_var = tk.DoubleVar(value=0.4)
        self.text_weight_scale = tk.Scale(
            face_ctrl_frame,
            from_=0.0,
            to=1.0,
            resolution=0.05,
            orient=tk.HORIZONTAL,
            variable=self.text_weight_var,
            length=180,
            bg='#1e1e1e',
            fg='white',
            highlightthickness=0,
        )
        self.text_weight_scale.grid(row=1, column=3, padx=8, sticky=tk.W)

        # Facial details display
        face_details_frame = ttk.Frame(left_panel)
        face_details_frame.grid(row=4, column=0, pady=10, sticky=(tk.W, tk.E))
        ttk.Label(face_details_frame, text="Facial Analysis Details:", font=('Segoe UI', 12, 'bold')).grid(row=0, column=0, sticky=tk.W, pady=5)
        self.face_details_text = scrolledtext.ScrolledText(face_details_frame, height=9, width=60,
                                                           font=('Segoe UI', 9), bg='#2d2d2d', fg='white', state=tk.DISABLED)
        self.face_details_text.grid(row=1, column=0, pady=5, sticky=(tk.W, tk.E))
        
        # Facial emotion display
        face_emotion_frame = ttk.Frame(left_panel)
        face_emotion_frame.grid(row=2, column=0, pady=10, sticky=(tk.W, tk.E))
        
        ttk.Label(face_emotion_frame, text="Current Facial Emotion:", font=('Segoe UI', 12, 'bold')).grid(row=0, column=0, sticky=tk.W)
        self.face_emotion_var = tk.StringVar(value="No face detected")
        self.face_emotion_label = tk.Label(face_emotion_frame, textvariable=self.face_emotion_var,
                                          font=('Segoe UI', 14, 'bold'), bg='#1e1e1e', fg='#FFD700')
        self.face_emotion_label.grid(row=1, column=0, sticky=tk.W)
        
        # Right panel - Text analysis and visualization
        right_panel = ttk.Frame(main_frame)
        right_panel.grid(row=1, column=1, padx=10, sticky=(tk.N, tk.S, tk.W, tk.E))
        
        # Text input section
        text_frame = ttk.Frame(right_panel)
        text_frame.grid(row=0, column=0, pady=10, sticky=(tk.W, tk.E))
        
        ttk.Label(text_frame, text="Text Sentiment Analysis:", font=('Segoe UI', 12, 'bold')).grid(row=0, column=0, sticky=tk.W, pady=5)
        
        self.text_input = scrolledtext.ScrolledText(text_frame, height=4, width=60,
                                                    font=('Segoe UI', 10), bg='#2d2d2d', fg='white',
                                                    insertbackground='white')
        self.text_input.grid(row=1, column=0, pady=5, sticky=(tk.W, tk.E))
        
        analyze_btn = tk.Button(text_frame, text="Analyze Text", command=self.analyze_text,
                               bg='#2196F3', fg='white', font=('Segoe UI', 10, 'bold'),
                               padx=15, pady=8, relief=tk.FLAT)
        analyze_btn.grid(row=2, column=0, pady=5)
        
        # Text emotion results
        self.text_result_var = tk.StringVar(value="Enter text to analyze")
        text_result_label = tk.Label(text_frame, textvariable=self.text_result_var,
                                    font=('Segoe UI', 12, 'bold'), bg='#1e1e1e', fg='#FFD700')
        text_result_label.grid(row=3, column=0, pady=10)
        
        # Detailed emotions display
        self.emotion_details_text = scrolledtext.ScrolledText(text_frame, height=6, width=60,
                                                             font=('Segoe UI', 9), bg='#2d2d2d',
                                                             fg='white', state=tk.DISABLED)
        self.emotion_details_text.grid(row=4, column=0, pady=5, sticky=(tk.W, tk.E))

        # Fusion results
        fusion_frame = ttk.Frame(right_panel)
        fusion_frame.grid(row=3, column=0, pady=10, sticky=(tk.W, tk.E))
        ttk.Label(fusion_frame, text="Multimodal Decision (Face + Text):", font=('Segoe UI', 12, 'bold')).grid(row=0, column=0, sticky=tk.W, pady=5)
        self.fusion_result_var = tk.StringVar(value="Waiting for face/text inputs")
        fusion_result_label = tk.Label(fusion_frame, textvariable=self.fusion_result_var,
                                       font=('Segoe UI', 12, 'bold'), bg='#1e1e1e', fg='#FFD700')
        fusion_result_label.grid(row=1, column=0, sticky=tk.W)

        self.fusion_details_text = scrolledtext.ScrolledText(fusion_frame, height=7, width=60,
                                                             font=('Segoe UI', 9), bg='#2d2d2d',
                                                             fg='white', state=tk.DISABLED)
        self.fusion_details_text.grid(row=2, column=0, pady=5, sticky=(tk.W, tk.E))
        
        # Visualization section
        viz_frame = ttk.Frame(right_panel)
        viz_frame.grid(row=1, column=0, pady=10, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        ttk.Label(viz_frame, text="Emotion Timeline:", font=('Segoe UI', 12, 'bold')).grid(row=0, column=0, sticky=tk.W, pady=5)
        
        # Create matplotlib figure for timeline
        self.fig = Figure(figsize=(6, 4), facecolor='#1e1e1e')
        self.ax = self.fig.add_subplot(111, facecolor='#2d2d2d')
        self.canvas = FigureCanvasTkAgg(self.fig, master=viz_frame)
        self.canvas.get_tk_widget().grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Statistics frame
        stats_frame = ttk.Frame(right_panel)
        stats_frame.grid(row=2, column=0, pady=10, sticky=(tk.W, tk.E))
        
        ttk.Label(stats_frame, text="Session Statistics:", font=('Segoe UI', 12, 'bold')).grid(row=0, column=0, sticky=tk.W, pady=5)
        
        self.stats_text = scrolledtext.ScrolledText(stats_frame, height=4, width=60,
                                                   font=('Segoe UI', 9), bg='#2d2d2d',
                                                   fg='white', state=tk.DISABLED)
        self.stats_text.grid(row=1, column=0, pady=5, sticky=(tk.W, tk.E))
        
        # Configure grid weights
        main_frame.columnconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(1, weight=1)
        right_panel.rowconfigure(1, weight=1)

        boot_label.destroy()
        
    def analyze_text(self):
        """Analyze text sentiment"""
        text = self._clean_text(self.text_input.get("1.0", tk.END))
        
        if not text:
            messagebox.showwarning("Empty Text", "Please enter some text to analyze.")
            return
            
        if self.text_model is None or self.text_tokenizer is None:
            messagebox.showerror("Model Error", "Text sentiment model not loaded.")
            return
            
        try:
            # Get predictions
            results = self._predict_text_emotions(text)
            
            # Sort by score
            results = sorted(results, key=lambda x: x['score'], reverse=True)
            
            # Display primary emotion
            primary = results[0]

            text_common = self._pipeline_distribution_to_common(results)
            dominant_common, dominant_conf = self._dominant_from_distribution(text_common)
            self.text_result_var.set(f"Primary Emotion: {dominant_common.upper()} ({dominant_conf*100:.1f}%)")
            
            # Display all emotions
            self.emotion_details_text.config(state=tk.NORMAL)
            self.emotion_details_text.delete("1.0", tk.END)
            self.emotion_details_text.insert("1.0", "Emotion Breakdown:\n\n")
            
            for i, result in enumerate(results, 1):
                emotion = result['label']
                score = result['score'] * 100
                bar = "█" * int(score / 5)
                self.emotion_details_text.insert(tk.END, f"{i}. {emotion.capitalize()}: {score:.1f}% {bar}\n")
            
            self.emotion_details_text.config(state=tk.DISABLED)
            
            # Add to history
            self.latest_text = {
                'raw_primary': primary['label'],
                'dominant_common': dominant_common,
                'confidence': dominant_conf,
                'distribution': text_common,
                'text': text,
                'timestamp': time.time(),
            }

            self.emotion_history.append({
                'timestamp': self.latest_text['timestamp'],
                'type': 'text',
                'emotion': dominant_common,
                'confidence': dominant_conf,
                'all_emotions': {k: float(v) for k, v in text_common.items()},
            })

            self._update_fusion_panel()
            
            self.update_visualization()
            self.update_statistics()
            
        except Exception as e:
            messagebox.showerror("Analysis Error", f"Error analyzing text: {str(e)}")
    
    def start_camera(self):
        """Start camera and emotion detection"""
        self.cap = cv2.VideoCapture(0)
        
        if not self.cap.isOpened():
            messagebox.showerror("Camera Error", "Unable to access camera.")
            return
            
        self.running = True
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        
        # Start video capture thread
        threading.Thread(target=self.capture_frames, daemon=True).start()
        
        # Start processing thread
        threading.Thread(target=self.process_frames, daemon=True).start()
        
        # Start display update
        self.update_video()
        
    def stop_camera(self):
        """Stop camera"""
        self.running = False
        if self.cap:
            self.cap.release()
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.video_label.config(image='')
        
    def capture_frames(self):
        """Capture frames from camera"""
        while self.running:
            ret, frame = self.cap.read()
            if ret:
                if not self.frame_queue.full():
                    self.frame_queue.put(frame.copy())
            time.sleep(0.03)  # ~30 FPS
            
    def process_frames(self):
        """Process frames for emotion detection"""
        while self.running:
            try:
                if not self.frame_queue.empty():
                    frame = self.frame_queue.get()
                    
                    # Analyze with DeepFace
                    try:
                        if self.DeepFace is None:
                            self.result_queue.put({'emotion': 'no_face', 'error': self.deepface_error or 'DeepFace unavailable'})
                            continue

                        backend = self.detector_backend_var.get() if hasattr(self, 'detector_backend_var') else 'retinaface'

                        try:
                            result = self.DeepFace.analyze(
                                frame,
                                actions=['emotion'],
                                enforce_detection=True,
                                detector_backend=backend,
                                silent=True,
                            )
                        except Exception:
                            result = self.DeepFace.analyze(
                                frame,
                                actions=['emotion'],
                                enforce_detection=False,
                                detector_backend='opencv',
                                silent=True,
                            )

                        faces = result if isinstance(result, list) else [result]
                        faces = [f for f in faces if isinstance(f, dict) and 'emotion' in f]
                        if not faces:
                            self.result_queue.put({'emotion': 'no_face'})
                            continue

                        def _area(face_dict: Dict[str, Any]) -> int:
                            region = face_dict.get('region') or {}
                            return int(region.get('w', 0)) * int(region.get('h', 0))

                        faces_sorted = sorted(faces, key=_area, reverse=True)
                        primary_face = faces_sorted[0]

                        emotions = primary_face.get('emotion', {})
                        dominant_face_label = str(primary_face.get('dominant_emotion', 'neutral'))
                        dominant_conf_face = float(emotions.get(dominant_face_label, 0.0)) / 100.0

                        face_common = self._face_distribution_to_common(emotions)

                        # smoothing over recent frames (common distribution)
                        self.face_smoothing_window.append(face_common)
                        smoothed = {k: 0.0 for k in self.common_emotions}
                        for d in self.face_smoothing_window:
                            for k in self.common_emotions:
                                smoothed[k] += float(d.get(k, 0.0))
                        n = max(1, len(self.face_smoothing_window))
                        smoothed = {k: v / n for k, v in smoothed.items()}
                        smoothed = self._ensure_common_distribution(smoothed)

                        dominant_common, dominant_common_conf = self._dominant_from_distribution(smoothed)
                        ts = time.time()

                        self.latest_face = {
                            'faces_count': len(faces_sorted),
                            'primary_region': primary_face.get('region'),
                            'dominant_face_label': dominant_face_label,
                            'dominant_face_conf': dominant_conf_face,
                            'dominant_common': dominant_common,
                            'confidence': dominant_common_conf,
                            'distribution': smoothed,
                            'raw_distribution': emotions,
                            'timestamp': ts,
                            'all_faces': faces_sorted,
                        }

                        self.emotion_history.append({
                            'timestamp': ts,
                            'type': 'face',
                            'emotion': dominant_common,
                            'confidence': dominant_common_conf,
                            'all_emotions': {k: float(v) for k, v in smoothed.items()},
                        })

                        self.result_queue.put({
                            'emotion': dominant_common,
                            'confidence': dominant_common_conf * 100.0,
                            'all_emotions': smoothed,
                            'region': primary_face.get('region'),
                            'faces_count': len(faces_sorted),
                        })
                        
                    except Exception as e:
                        self.result_queue.put({'emotion': 'no_face', 'error': str(e)})
                        
            except queue.Empty:
                pass
            time.sleep(0.1)
            
    def update_video(self):
        """Update video display"""
        if self.running and self.cap and self.cap.isOpened():
            ret, frame = self.cap.read()
            
            if ret:
                # Get latest emotion result
                try:
                    while not self.result_queue.empty():
                        result = self.result_queue.get_nowait()
                        
                        if 'emotion' in result and result['emotion'] != 'no_face':
                            emotion = result['emotion']
                            confidence = float(result.get('confidence', 0.0))
                            
                            # Update label
                            self.face_emotion_var.set(f"{emotion.upper()} ({confidence:.1f}%)")
                            
                            # Draw on frame
                            cv2.putText(frame, f"{emotion}: {confidence:.1f}%", 
                                      (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                                      1, (0, 255, 0), 2)

                            # Face bbox (if available)
                            region = result.get('region')
                            if isinstance(region, dict):
                                x = int(region.get('x', 0))
                                y = int(region.get('y', 0))
                                w = int(region.get('w', 0))
                                h = int(region.get('h', 0))
                                if w > 0 and h > 0:
                                    cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                            
                            # Draw emotion bars
                            if 'all_emotions' in result:
                                y_offset = 70
                                for emo, val in sorted(result['all_emotions'].items(),
                                                     key=lambda x: x[1], reverse=True)[:3]:
                                    val_pct = float(val) * 100.0
                                    bar_len = int(val_pct * 2)
                                    cv2.rectangle(frame, (10, y_offset), 
                                                (10 + bar_len, y_offset + 20),
                                                (0, 255, 0), -1)
                                    cv2.putText(frame, f"{emo}: {val_pct:.1f}%",
                                              (10, y_offset + 15),
                                              cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                                              (255, 255, 255), 1)
                                    y_offset += 30

                            self._update_face_details_panel(result)
                            self._update_fusion_panel()
                        else:
                            self.face_emotion_var.set("No face detected")
                            
                except queue.Empty:
                    pass
                
                # Convert and display
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frame = cv2.resize(frame, (640, 480))
                img = Image.fromarray(frame)
                imgtk = ImageTk.PhotoImage(image=img)
                self.video_label.imgtk = imgtk
                self.video_label.configure(image=imgtk)
                
            # Update visualization periodically
            if len(self.emotion_history) > 0 and len(self.emotion_history) % 5 == 0:
                self.update_visualization()
                self.update_statistics()
                
            self.root.after(30, self.update_video)
            
    def update_visualization(self):
        """Update emotion timeline visualization"""
        if len(self.emotion_history) < 2:
            return
            
        self.ax.clear()
        
        # Prepare data
        face_times, face_emotions = [], []
        text_times, text_emotions = [], []
        
        emotion_mapping = {
            'anger': 0, 'disgust': 1, 'fear': 2, 'joy': 3,
            'sadness': 4, 'surprise': 5, 'neutral': 6,
        }
        
        base_time = self.emotion_history[0]['timestamp']
        
        for entry in self.emotion_history:
            rel_time = entry['timestamp'] - base_time
            emotion_val = emotion_mapping.get(entry['emotion'], 6)
            
            if entry['type'] == 'face':
                face_times.append(rel_time)
                face_emotions.append(emotion_val)
            else:
                text_times.append(rel_time)
                text_emotions.append(emotion_val)
        
        # Plot
        if face_times:
            self.ax.plot(face_times, face_emotions, 'o-', label='Facial', 
                        color='#4CAF50', markersize=6, linewidth=2)
        if text_times:
            self.ax.plot(text_times, text_emotions, 's-', label='Text', 
                        color='#2196F3', markersize=6, linewidth=2)
        
        self.ax.set_yticks(range(7))
        self.ax.set_yticklabels(['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral'])
        self.ax.set_xlabel('Time (seconds)', color='white')
        self.ax.set_ylabel('Emotion', color='white')
        self.ax.tick_params(colors='white')
        self.ax.grid(True, alpha=0.3)
        self.ax.legend(facecolor='#2d2d2d', edgecolor='white', labelcolor='white')
        
        for spine in self.ax.spines.values():
            spine.set_color('white')
        
        self.fig.tight_layout()
        self.canvas.draw()
        
    def update_statistics(self):
        """Update session statistics"""
        if not self.emotion_history:
            return
            
        face_emotions = [e for e in self.emotion_history if e['type'] == 'face']
        text_emotions = [e for e in self.emotion_history if e['type'] == 'text']
        
        stats = f"Total Detections: {len(self.emotion_history)}\n"
        stats += f"Facial: {len(face_emotions)} | Text: {len(text_emotions)}\n\n"
        
        if face_emotions:
            face_counts = {}
            for e in face_emotions:
                face_counts[e['emotion']] = face_counts.get(e['emotion'], 0) + 1
            dominant_face = max(face_counts.items(), key=lambda x: x[1])
            stats += f"Dominant Facial: {dominant_face[0].upper()} ({dominant_face[1]} times)\n"
        
        if text_emotions:
            text_counts = {}
            for e in text_emotions:
                text_counts[e['emotion']] = text_counts.get(e['emotion'], 0) + 1
            dominant_text = max(text_counts.items(), key=lambda x: x[1])
            stats += f"Dominant Text: {dominant_text[0].upper()} ({dominant_text[1]} times)"
        
        self.stats_text.config(state=tk.NORMAL)
        self.stats_text.delete("1.0", tk.END)
        self.stats_text.insert("1.0", stats)
        self.stats_text.config(state=tk.DISABLED)

    def _update_face_details_panel(self, face_result: Dict[str, Any]):
        faces_count = int(face_result.get('faces_count', 0))
        emotion = str(face_result.get('emotion', 'neutral'))
        confidence = float(face_result.get('confidence', 0.0))
        dist = face_result.get('all_emotions') or {}

        lines = []
        lines.append("FACIAL ANALYSIS")
        lines.append("-" * 40)
        lines.append(f"Detected faces: {faces_count}")
        lines.append(f"Dominant emotion: {emotion.upper()} ({confidence:.1f}%)")
        lines.append("")
        lines.append("Top emotions (smoothed):")
        for emo, val in sorted(dist.items(), key=lambda x: x[1], reverse=True)[:5]:
            lines.append(f"  - {str(emo).upper()}: {float(val)*100.0:.1f}%")

        self.face_details_text.config(state=tk.NORMAL)
        self.face_details_text.delete("1.0", tk.END)
        self.face_details_text.insert("1.0", "\n".join(lines))
        self.face_details_text.config(state=tk.DISABLED)

    def _update_fusion_panel(self):
        face_dist = self.latest_face.get('distribution') if self.latest_face else None
        text_dist = self.latest_text.get('distribution') if self.latest_text else None

        fused = self._fuse(face_dist, text_dist)
        self.latest_fused = fused

        dominant = fused['dominant_emotion']
        conf = fused['confidence']
        agree = fused.get('agreement')

        if agree is True:
            agree_str = "Agreement: YES"
        elif agree is False:
            agree_str = "Agreement: NO"
        else:
            agree_str = "Agreement: N/A"

        self.fusion_result_var.set(f"Final Emotion: {dominant.upper()} ({conf*100.0:.1f}%)")

        lines = []
        lines.append("MULTIMODAL DECISION")
        lines.append("-" * 40)
        lines.append(f"Weights -> Face: {fused['face_weight']:.2f} | Text: {fused['text_weight']:.2f}")
        lines.append(agree_str)
        if self.latest_face:
            lines.append(f"Face dominant: {self.latest_face.get('dominant_common','').upper()} ({self.latest_face.get('confidence',0.0)*100.0:.1f}%)")
        else:
            lines.append("Face dominant: N/A")
        if self.latest_text:
            lines.append(f"Text dominant: {self.latest_text.get('dominant_common','').upper()} ({self.latest_text.get('confidence',0.0)*100.0:.1f}%)")
        else:
            lines.append("Text dominant: N/A")
        lines.append("")
        lines.append("Fused distribution:")
        for emo, val in sorted((fused.get('distribution') or {}).items(), key=lambda x: x[1], reverse=True):
            lines.append(f"  - {str(emo).upper()}: {float(val)*100.0:.1f}%")

        self.fusion_details_text.config(state=tk.NORMAL)
        self.fusion_details_text.delete("1.0", tk.END)
        self.fusion_details_text.insert("1.0", "\n".join(lines))
        self.fusion_details_text.config(state=tk.DISABLED)
        
    def run(self):
        """Start the application"""
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.root.mainloop()
        
    def on_closing(self):
        """Handle application closing"""
        self.stop_camera()
        self.root.destroy()

if __name__ == "__main__":
    print("=" * 60)
    print("Multimodal Emotion Recognition System")
    print("=" * 60)
    app = MultimodalEmotionRecognizer()
    app.run()