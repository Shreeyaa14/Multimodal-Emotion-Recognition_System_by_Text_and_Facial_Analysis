import time
from typing import Any, Dict, Optional, Tuple

import numpy as np
import pandas as pd
import streamlit as st
from PIL import Image, ImageOps


def _patch_huggingface_hub_compat() -> None:
    try:
        import inspect
        import huggingface_hub

        sig = inspect.signature(huggingface_hub.hf_hub_download)
        if "use_auth_token" in sig.parameters:
            return

        original = huggingface_hub.hf_hub_download

        def hf_hub_download_compat(*args, use_auth_token=None, token=None, **kwargs):
            if token is None and use_auth_token is not None:
                token = use_auth_token
            return original(*args, token=token, **kwargs)

        huggingface_hub.hf_hub_download = hf_hub_download_compat
        try:
            import huggingface_hub.file_download

            huggingface_hub.file_download.hf_hub_download = hf_hub_download_compat
        except Exception:
            pass
    except Exception:
        return


_patch_huggingface_hub_compat()


def _read_streamlit_image(img_source) -> Image.Image:
    from io import BytesIO

    if hasattr(img_source, "getvalue"):
        data = img_source.getvalue()
        img = Image.open(BytesIO(data))
    else:
        img = Image.open(img_source)
    img = ImageOps.exif_transpose(img)
    return img.convert("RGB")


COMMON_EMOTIONS = ("anger", "disgust", "fear", "joy", "sadness", "surprise", "neutral")
FACE_TO_COMMON = {
    "angry": "anger",
    "disgust": "disgust",
    "fear": "fear",
    "happy": "joy",
    "sad": "sadness",
    "surprise": "surprise",
    "neutral": "neutral",
}


def _ensure_common_distribution(probs: Optional[Dict[str, float]]) -> Dict[str, float]:
    out = {k: 0.0 for k in COMMON_EMOTIONS}
    for k, v in (probs or {}).items():
        if k in out:
            out[k] = float(v)
    total = float(sum(out.values()))
    if total > 0:
        out = {k: (v / total) for k, v in out.items()}
    return out


def _dominant_from_distribution(dist: Dict[str, float]) -> Tuple[str, float]:
    if not dist:
        return "neutral", 0.0
    emotion = max(dist.items(), key=lambda x: x[1])[0]
    return emotion, float(dist.get(emotion, 0.0))


def _face_distribution_to_common(deepface_emotions: Optional[Dict[str, Any]]) -> Dict[str, float]:
    mapped = {k: 0.0 for k in COMMON_EMOTIONS}
    if not deepface_emotions:
        return mapped
    for face_label, val in deepface_emotions.items():
        common = FACE_TO_COMMON.get(str(face_label).lower().strip())
        if common is not None:
            try:
                mapped[common] += float(val) / 100.0
            except Exception:
                mapped[common] += 0.0
    return _ensure_common_distribution(mapped)


def _pipeline_distribution_to_common(results) -> Dict[str, float]:
    mapped = {k: 0.0 for k in COMMON_EMOTIONS}
    for r in (results or []):
        label = str(r.get("label", "")).strip().lower()
        score = float(r.get("score", 0.0))
        if label in mapped:
            mapped[label] = score
    return _ensure_common_distribution(mapped)


@st.cache_resource(show_spinner=False)
def load_text_model(model_name: str):
    import os

    os.environ.setdefault("TRANSFORMERS_NO_TF", "1")
    os.environ.setdefault("USE_TF", "0")
    os.environ.setdefault("USE_FLAX", "0")

    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(model_name)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    model.eval()

    return tokenizer, model, device


@st.cache_resource(show_spinner=False)
def load_deepface():
    import tensorflow.keras  # type: ignore
    from deepface import DeepFace  # type: ignore

    return DeepFace


def predict_text_emotions(text: str, model_name: str) -> Dict[str, Any]:
    import torch

    tokenizer, model, device = load_text_model(model_name)

    inputs = tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        padding=True,
        max_length=256,
    )
    inputs = {k: v.to(device) for k, v in inputs.items()}

    with torch.no_grad():
        outputs = model(**inputs)
        logits = outputs.logits
        probs = torch.softmax(logits, dim=-1).squeeze(0)

    id2label = getattr(model.config, "id2label", None) or {}
    results = []
    for idx in range(int(probs.shape[-1])):
        label = str(id2label.get(idx, str(idx))).strip().lower()
        score = float(probs[idx].item())
        results.append({"label": label, "score": score})

    common_dist = _pipeline_distribution_to_common(results)
    dominant, conf = _dominant_from_distribution(common_dist)

    return {
        "model_name": model_name,
        "distribution": common_dist,
        "dominant_emotion": dominant,
        "confidence": conf,
        "raw": results,
    }


def analyze_face_emotions(img_bgr: np.ndarray, detector_backend: str, enforce_detection: bool) -> Dict[str, Any]:
    from pathlib import Path

    weights_path = Path.home() / ".deepface" / "weights" / "facial_expression_model_weights.h5"
    if not weights_path.is_file():
        raise FileNotFoundError(
            f"DeepFace emotion model weights not found at {weights_path}. "
            "Please ensure the model file is available."
        )

    DeepFace = load_deepface()

    result = DeepFace.analyze(
        img_bgr,
        actions=["emotion"],
        detector_backend=detector_backend,
        enforce_detection=enforce_detection,
        silent=True,
    )

    if isinstance(result, list):
        result = result[0] if result else {}

    emotions = (result or {}).get("emotion") or {}
    common_dist = _face_distribution_to_common(emotions)
    dominant, conf = _dominant_from_distribution(common_dist)

    return {
        "detector_backend": detector_backend,
        "enforce_detection": enforce_detection,
        "distribution": common_dist,
        "dominant_emotion": dominant,
        "confidence": conf,
        "raw": result,
    }


def fuse(face_dist: Optional[Dict[str, float]], text_dist: Optional[Dict[str, float]], face_w: float, text_w: float) -> Dict[str, Any]:
    face_w = max(0.0, float(face_w))
    text_w = max(0.0, float(text_w))

    face_common = _ensure_common_distribution(face_dist)
    text_common = _ensure_common_distribution(text_dist)

    if sum(face_common.values()) == 0 and sum(text_common.values()) == 0:
        fused = {k: 0.0 for k in COMMON_EMOTIONS}
    else:
        fused = {k: face_w * face_common.get(k, 0.0) + text_w * text_common.get(k, 0.0) for k in COMMON_EMOTIONS}
        fused = _ensure_common_distribution(fused)

    dominant, conf = _dominant_from_distribution(fused)
    return {
        "face_weight": face_w,
        "text_weight": text_w,
        "distribution": fused,
        "dominant_emotion": dominant,
        "confidence": conf,
    }


def dist_table(dist: Dict[str, float]) -> pd.DataFrame:
    df = pd.DataFrame({"emotion": list(dist.keys()), "probability": list(dist.values())})
    df["percent"] = (df["probability"] * 100.0).round(2)
    df = df.sort_values("probability", ascending=False).reset_index(drop=True)
    return df


def main():
    st.set_page_config(page_title="Multimodal Emotion Recognition", page_icon="🎭", layout="wide")

    st.markdown(
        """
<style>
.block-container { padding-top: 1.25rem; padding-bottom: 3rem; }
[data-testid="stMetricValue"] { font-size: 1.4rem; }
.section-card { border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 1rem 1.1rem; background: rgba(255,255,255,0.03); }
.small-muted { opacity: 0.75; font-size: 0.9rem; }
</style>
        """,
        unsafe_allow_html=True,
    )

    st.title("Multimodal Emotion Recognition")
    st.caption("Text emotion + face emotion (image/camera) with optional fusion")

    with st.sidebar:
        st.subheader("Settings")
        text_model_name = st.text_input(
            "Text model",
            value="j-hartmann/emotion-english-distilroberta-base",
            help="Hugging Face model name",
        )

        st.markdown("---")
        st.subheader("Face Analysis")
        detector_backend = st.selectbox(
            "Detector backend",
            options=["retinaface", "mtcnn", "opencv", "ssd", "dlib", "mediapipe"],
            index=0,
        )
        enforce_detection = st.checkbox("Enforce detection", value=False)

        st.markdown("---")
        st.subheader("Fusion")
        col_w1, col_w2 = st.columns(2)
        with col_w1:
            face_w = st.slider("Face weight", min_value=0.0, max_value=1.0, value=0.6, step=0.05)
        with col_w2:
            text_w = st.slider("Text weight", min_value=0.0, max_value=1.0, value=0.4, step=0.05)

    col_left, col_right = st.columns([1.05, 0.95], gap="large")

    with col_left:
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        st.subheader("Text Emotion")
        text = st.text_area(
            "Input text",
            placeholder="Type something like: I'm so excited about this amazing opportunity!",
            height=140,
        )
        analyze_text = st.button("Analyze Text", type="primary", use_container_width=True)

        text_result = None
        if analyze_text:
            if not text.strip():
                st.warning("Please enter some text.")
            else:
                with st.spinner("Analyzing text..."):
                    start = time.time()
                    text_result = predict_text_emotions(text.strip(), text_model_name)
                    elapsed = time.time() - start
                st.success(f"Text analysis complete in {elapsed:.2f}s")
                st.session_state["text_result"] = text_result

        text_result = text_result or st.session_state.get("text_result")
        if text_result:
            dom = text_result["dominant_emotion"]
            conf = float(text_result["confidence"]) * 100.0
            m1, m2 = st.columns(2)
            m1.metric("Dominant emotion", dom)
            m2.metric("Confidence", f"{conf:.2f}%")
            df = dist_table(text_result["distribution"])
            st.dataframe(df[["emotion", "percent"]], use_container_width=True, hide_index=True)
            st.bar_chart(df.set_index("emotion")["probability"], use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

    with col_right:
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        st.subheader("Face Emotion")

        camera_img = st.camera_input("Capture (optional)")
        upload_img = st.file_uploader("Or upload an image", type=["png", "jpg", "jpeg", "webp"])

        img_source = camera_img or upload_img
        face_result = None

        analyze_face = st.button("Analyze Face", use_container_width=True)

        if analyze_face:
            if img_source is None:
                st.warning("Please capture or upload an image.")
            else:
                try:
                    img = _read_streamlit_image(img_source)
                    img_arr = np.asarray(img)
                    if img_arr.ndim == 2:
                        img_arr = np.stack([img_arr, img_arr, img_arr], axis=-1)
                    if img_arr.ndim != 3 or img_arr.shape[-1] != 3:
                        raise ValueError(f"Unsupported image shape: {getattr(img_arr, 'shape', None)}")
                    if img_arr.dtype != np.uint8:
                        img_arr = img_arr.astype(np.uint8)
                    img_arr = np.ascontiguousarray(img_arr)
                    img_bgr = np.ascontiguousarray(img_arr[:, :, ::-1])
                    with st.spinner("Analyzing face emotions..."):
                        start = time.time()
                        face_result = analyze_face_emotions(
                            img_bgr,
                            detector_backend=detector_backend,
                            enforce_detection=enforce_detection,
                        )
                        elapsed = time.time() - start
                    st.success(f"Face analysis complete in {elapsed:.2f}s")
                    st.session_state["face_result"] = face_result
                    st.image(img, caption="Input image", use_container_width=True)
                except Exception as e:
                    st.error(f"Face analysis failed: {e}")
                    st.exception(e)

        face_result = face_result or st.session_state.get("face_result")

        if face_result:
            dom = face_result["dominant_emotion"]
            conf = float(face_result["confidence"]) * 100.0
            m1, m2 = st.columns(2)
            m1.metric("Dominant emotion", dom)
            m2.metric("Confidence", f"{conf:.2f}%")
            df = dist_table(face_result["distribution"])
            st.dataframe(df[["emotion", "percent"]], use_container_width=True, hide_index=True)
            st.bar_chart(df.set_index("emotion")["probability"], use_container_width=True)

        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("---")
    st.subheader("Fused Emotion (Face + Text)")
    st.markdown('<div class="section-card">', unsafe_allow_html=True)

    text_result = st.session_state.get("text_result")
    face_result = st.session_state.get("face_result")

    fused = fuse(
        face_dist=(face_result or {}).get("distribution"),
        text_dist=(text_result or {}).get("distribution"),
        face_w=face_w,
        text_w=text_w,
    )

    m1, m2, m3 = st.columns(3)
    m1.metric("Dominant emotion", fused["dominant_emotion"])
    m2.metric("Confidence", f"{float(fused['confidence']) * 100.0:.2f}%")
    m3.metric("Weights", f"face={fused['face_weight']:.2f}, text={fused['text_weight']:.2f}")

    df = dist_table(fused["distribution"])
    st.dataframe(df[["emotion", "percent"]], use_container_width=True, hide_index=True)
    st.bar_chart(df.set_index("emotion")["probability"], use_container_width=True)

    if (text_result is None) and (face_result is None):
        st.markdown('<div class="small-muted">Run at least one analysis above to get meaningful fusion output.</div>', unsafe_allow_html=True)

    st.markdown("</div>", unsafe_allow_html=True)


if __name__ == "__main__":
    main()
